// expresión que compare dos strings y produzca un valor TRUE
console.log("merche" === "merche");

// expresión comparando dos strings que devuelva FALSE
console.log("hola" === "gato");

// expresión que involucre un string y un número y devuelva FALSE
console.log("3" === 3);

// comparación entre un string y un número que devuelva TRUE:
console.log("2" == 2);